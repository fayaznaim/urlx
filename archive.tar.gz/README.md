# work in progress !!

## The main file is urlx.py - the other files are reference within it and should be in the same folder. 


This is a python script(s) that will give the results of the url reputation. 

Currently it gives the results from the following repuation analysis sites: 

1. urlvoid.com
2. safeweb.norton.com
3. talosintelligence.com
4. threatminer.org
5. abuseipdb.com


