#!/usr/bin/env python3
from urllib import request
import urllib
import re


def abuseipdb(urlx):
    abuseipdburl = ("https://www.abuseipdb.com/check/" + urlx)
    print("ABUSEIPDB.COM: " + abuseipdburl)
    # webbrowser.open(abuseipdburl)

