#!/usr/bin/env python3


def introscreen():
    print("         ***   URL ANALYSIS SCRIPT FOR CYBER ANALYSTS   ***\n")
    print("         This program provides analysis information via the following websites.\n"
          "         [ URLVoid ][ Norton Safeweb ][ TALOSIntelligence ][ ThreatMiner ][ AbuseIPDB ]\n"
          "         Also displays the scraped desired text in the output.\n\n")

